//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop


#include "Unit2.h"
#include "Project1PCH1.h"
#include "Unit3.h"
#include "Unit1.h"
#include <stdlib.h>

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
int sb = 8, sr = 8;
bool BlueLeft, BlueRight, BlueUp, BlueDown = {false};
bool RedLeft, RedRight, RedUp, RedDown = {false};

//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{

}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)

{
   if(Key == VK_LEFT)
   {
	   BlueLeft = true;
   }
   if(Key == VK_RIGHT)
   {
	   BlueRight = true;
   }
   if(Key == VK_UP)
   {
	   BlueUp = true;
   }
   if(Key == VK_DOWN)
   {
	   BlueDown = true;
   }
   if(Key == VK_SPACE)
   {

   }

   if(Key == 'a')
   {
	  RedLeft = true;
   }
   if(Key == 'd')
   {
	  RedRight = true;
   }
   if(Key == 'w')
   {
	  RedUp = true;
   }
   if(Key == 's')
   {
	  RedDown = true;
   }
   if(Key == 'f')
   {

   }




}
//---------------------------------------------------------------------------

void __fastcall TForm2::TimerRedTimer(TObject *Sender)
{
	 if(RedLeft == true)
	 {
		PlayerRed -> Left -= 10;
	 }
	 if(RedRight == true)
	 {
		 PlayerRed -> Left += 10;
	 }
	 if(RedUp == true)
	 {
		 PlayerRed -> Top -= 10;
	 }
	 if(RedDown == true)
	 {
		 PlayerRed -> Top += 10;
	 }

}
//---------------------------------------------------------------------------

void __fastcall TForm2::BackClick(TObject *Sender)
{
     	 if(BlueLeft == true)
	 {
		PlayerBlue -> Left -= 10;
	 }
	 if(BlueRight == true)
	 {
		 PlayerBlue -> Left += 10;
	 }
	 if(BlueUp == true)
	 {
		 PlayerBlue -> Top -= 10;
	 }
	 if(BlueDown == true)
	 {
		 PlayerBlue -> Top += 10;
	 }

}
//---------------------------------------------------------------------------



void __fastcall TForm2::FormClose(TObject *Sender, TCloseAction &Action)
{
Application -> Terminate();
}
//---------------------------------------------------------------------------


