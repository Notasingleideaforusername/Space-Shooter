//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
#include "Project1PCH1.h"
#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

TForm1 *Form1;

   bool check_collision(int enemyleft, int enemytop, int shotleft, int shottop)
{
	if((shotleft>enemyleft-10) &&
	   (shotleft + 10 < enemyleft + 60) &&
	   (shottop < enemytop +50) &&
	   (shottop + 10 > enemytop + 50))
	   {
		  return true;
	   }
	   else
	   {
		   return false;
	   }
}
   bool check_top(int shottop)
   {
	   if(shottop < 0)
	   {
		   return true;
	   }
	   else
	   {
		   return false;
       }


   }



bool a, b, c, d, e, f, g, h, i, j, k, l = {false};
int direction1, direction2, direction3;
int x1 =5, z1 =5, xy1 = 3;
int x2 =5, z2 =5, xy2 = 3;
int x3 =5, z3 =5, xy3 = 3;
int n = 0, p = 12;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{


	randomize();
	direction1 = rand()%8;
	direction2 = rand()%8;
	direction3 = rand()%8;


	Enemy1 -> Left = rand()%577 + Back -> Left + 50;
	Enemy2 -> Left = rand()%577 + Back -> Left + 50;
	Enemy2 -> Left = rand()%577 + Back -> Left + 50;

	Enemy1 -> Top =  rand()%150;
	Enemy2 -> Top =  rand()%150;
	Enemy3 -> Top =  rand()%150;


}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerLeftTimer(TObject *Sender)
{
	if(Image1 -> Left -10 > Back -> Left)
	{
	Image1 -> Left = Image1 -> Left - 10;
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerRightTimer(TObject *Sender)
{
	if(Image1 -> Left + Image1 -> Width + 18 <= Back -> Width + Back -> Left)
	{
		Image1 -> Left = Image1 -> Left + 10;
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
	if(Key == VK_LEFT) TimerLeft -> Enabled = false;
	if(Key == VK_RIGHT) TimerRight -> Enabled = false;
	if(Key == VK_UP) TimerUp -> Enabled = false;
	if(Key == VK_DOWN) TimerDown -> Enabled = false;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)

{
	if(Key == VK_LEFT) TimerLeft -> Enabled = true;
	if(Key == VK_RIGHT) TimerRight -> Enabled = true;
	if(Key == VK_UP) TimerUp -> Enabled = true;
	if(Key == VK_DOWN) TimerDown -> Enabled = true;

	if(Key == VK_SPACE)
	{
	p--;
	if(a == false)
	{
	  a = true;
	  TimerShot -> Enabled = true;
	  Shot1 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot1 -> Width/2;
	  Shot1 -> Top = Image1 -> Top - 15;
	}
	else if (b == false)
	{
	  b = true;
	  TimerShot -> Enabled = true;
	  Shot2 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot2 -> Width/2;
	  Shot2 -> Top = Image1 -> Top - 15;
	}
		else if (c == false)
	{
	  c = true;
	  TimerShot -> Enabled = true;
	  Shot3 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot3 -> Width/2;
	  Shot3 -> Top = Image1 -> Top - 15;
	}
		else if (d == false)
	{
	  d = true;
	  TimerShot -> Enabled = true;
	  Shot4 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot4 -> Width/2;
	  Shot4 -> Top = Image1 -> Top - 15;
	}
		else if (e == false)
	{
	  e = true;
	  TimerShot -> Enabled = true;
	  Shot5 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot5 -> Width/2;
	  Shot5 -> Top = Image1 -> Top - 15;
	}
		else if (f == false)
	{
	  f = true;
	  TimerShot -> Enabled = true;
	  Shot6 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot6 -> Width/2;
	  Shot6 -> Top = Image1 -> Top - 15;
	}
		else if (g == false)
	{
	  g = true;
	  TimerShot -> Enabled = true;
	  Shot7 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot7 -> Width/2;
	  Shot7 -> Top = Image1 -> Top - 15;
	}
		else if (h == false)
	{
	  h = true;
	  TimerShot -> Enabled = true;
	  Shot8 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot8 -> Width/2;
	  Shot8 -> Top = Image1 -> Top - 15;
	}
		else if (i == false)
	{
	  i = true;
	  TimerShot -> Enabled = true;
	  Shot9 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot9 -> Width/2;
	  Shot9 -> Top = Image1 -> Top - 15;
	}
		else if (j == false)
	{
	  j = true;
	  TimerShot -> Enabled = true;
	  Shot10 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot10 -> Width/2;
	  Shot10 -> Top = Image1 -> Top - 15;
	}
		else if (k == false)
	{
	  k = true;
	  TimerShot -> Enabled = true;
	  Shot11 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot11 -> Width/2;
	  Shot11 -> Top = Image1 -> Top - 15;
	}
		else if (l == false)
	{
	  l = true;
	  TimerShot -> Enabled = true;
	  Shot12 -> Left = Image1 -> Left + Image1 -> Width/2 - Shot12 -> Width/2;
	  Shot12 -> Top = Image1 -> Top - 15;
	}
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerUpTimer(TObject *Sender)
{
if(Image1 -> Top >= Back -> Height/1.5)
{
	Image1 -> Top = Image1 -> Top - 10;
}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerDownTimer(TObject *Sender)
{
if(Image1 -> Top + Image1 -> Height +5 <= Back -> Height)
{
	Image1 -> Top = Image1 -> Top + 10;
}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerShotTimer(TObject *Sender)
{
 if (a==true)Shot1 -> Top -= 15;
 if (b==true)Shot2 -> Top -= 15;
 if (c==true)Shot3 -> Top -= 15;
 if (d==true)Shot4 -> Top -= 15;
 if (e==true)Shot5 -> Top -= 15;
 if (f==true)Shot6 -> Top -= 15;
 if (g==true)Shot7 -> Top -= 15;
 if (h==true)Shot8 -> Top -= 15;
 if (i==true)Shot9 -> Top -= 15;
 if (j==true)Shot10 -> Top -= 15;
 if (k==true)Shot11 -> Top -= 15;
 if (l==true)Shot12 -> Top -= 15;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::TimerEnemyMovementTimer(TObject *Sender)
{
   if(direction1 == 0)
   {
	   Enemy1 -> Top -= z1;
   }
   else if (direction1 == 1)
   {
	   Enemy1 -> Top -= xy1;
	   Enemy1 -> Left += xy1;
   }
   else if (direction1 == 2)
   {
	   Enemy1 -> Left += x1;
   }
   else if (direction1 == 3)
   {
	   Enemy1 -> Top += xy1;
	   Enemy1 -> Left += xy1;
   }
   else if (direction1 == 4)
   {
	   Enemy1 -> Top += z1;
   }
   else if (direction1 == 5)
   {
	   Enemy1 -> Top += xy1;
	   Enemy1 -> Left -= xy1;
   }
   else if (direction1 == 6)
   {
	   Enemy1 -> Left -= x1;
   }
   else if (direction1 == 7)
   {
	   Enemy1 -> Top += xy1;
	   Enemy1 -> Left -= xy1;
   }


   if (Enemy1 -> Left < Back -> Left)
   {
	   x1 = -x1;
	   xy1 = -xy1;
   }

   if (Enemy1 -> Left + Enemy1 -> Width > Back -> Left + Back -> Width)
   {
	   x1 = -x1;
	   xy1 = -xy1;
   }

   if (Enemy1 -> Top < Back -> Top)
   {
	   z1 = -z1;
	   xy1 = -xy1;
   }

   if (Enemy1 -> Top + Enemy1 -> Height > Back -> Height/3)
   {
	  z1 = -z1;
	  xy1 = -xy1;
   }


    if(direction2 == 0)
   {
	   Enemy2 -> Top -= z2;
   }
   else if (direction2 == 1)
   {
	   Enemy2 -> Top -= xy2;
	   Enemy2 -> Left += xy2;
   }
   else if (direction2 == 2)
   {
	   Enemy2 -> Left += x2;
   }
   else if (direction2 == 3)
   {
	   Enemy2 -> Top += xy2;
	   Enemy2 -> Left += xy2;
   }
   else if (direction2 == 4)
   {
	   Enemy2 -> Top += z2;
   }
   else if (direction2 == 5)
   {
	   Enemy2 -> Top += xy2;
	   Enemy2 -> Left -= xy2;
   }
   else if (direction2 == 6)
   {
	   Enemy2 -> Left -= x2;
   }
   else if (direction2 == 7)
   {
	   Enemy2 -> Top += xy2;
	   Enemy2 -> Left -= xy2;
   }


   if (Enemy2 -> Left < Back -> Left)
   {
	   x2 = -x2;
	   xy2 = -xy2;
   }

   if (Enemy2 -> Left + Enemy2 -> Width > Back -> Left + Back -> Width)
   {
	   x2 = -x2;
	   xy2 = -xy2;
   }

   if (Enemy2 -> Top < Back -> Top)
   {
	   z2 = -z2;
	   xy2 = -xy2;
   }

   if (Enemy2 -> Top + Enemy2 -> Height > Back -> Height/3)
   {
	  z2 = -z2;
	  xy2 = -xy2;
   }

     if(direction3 == 0)
   {
	   Enemy3 -> Top -= z3;
   }
   else if (direction3 == 1)
   {
	   Enemy3 -> Top -= xy3;
	   Enemy3 -> Left += xy3;
   }
   else if (direction3 == 2)
   {
	   Enemy3 -> Left += x3;
   }
   else if (direction3 == 3)
   {
	   Enemy3 -> Top += xy3;
	   Enemy3 -> Left += xy3;
   }
   else if (direction3 == 4)
   {
	   Enemy3 -> Top += z3;
   }
   else if (direction3 == 5)
   {
	   Enemy3 -> Top += xy3;
	   Enemy3 -> Left -= xy3;
   }
   else if (direction3 == 6)
   {
	   Enemy3 -> Left -= x3;
   }
   else if (direction3 == 7)
   {
	   Enemy3 -> Top += xy3;
	   Enemy3 -> Left -= xy3;
   }


   if (Enemy3 -> Left < Back -> Left)
   {
	   x3 = -x3;
	   xy3 = -xy3;
   }

   if (Enemy3 -> Left + Enemy3 -> Width > Back -> Left + Back -> Width)
   {
	   x3 = -x3;
	   xy3 = -xy3;
   }

   if (Enemy3 -> Top < Back -> Top)
   {
	   z3 = -z3;
	   xy3 = -xy3;
   }

   if (Enemy3 -> Top + Enemy3 -> Height > Back -> Height/3)
   {
	  z3 = -z3;
	  xy3 = -xy3;
   }

}
//---------------------------------------------------------------------------


void __fastcall TForm1::TimerCollisionTimer(TObject *Sender)
{
	Label1 -> Caption = n;
    Label3 -> Caption = p;



	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot1 -> Left, Shot1 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot2 -> Left, Shot2 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot3 -> Left, Shot3 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot4 -> Left, Shot4 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot5 -> Left, Shot5 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot6 -> Left, Shot6 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot7 -> Left, Shot7 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot8 -> Left, Shot8 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot9 -> Left, Shot9 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot10 -> Left, Shot10 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot11 -> Left, Shot11 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy1 -> Left, Enemy1 -> Top, Shot12 -> Left, Shot12 -> Top) == true)
	  {
		  Enemy1 -> Enabled = false;
		  Enemy1 -> Visible = false;
		  Enemy1 -> Left = -100;
		  n++;
	  }



       if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot1 -> Left, Shot1 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
          Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot2 -> Left, Shot2 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot3 -> Left, Shot3 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot4 -> Left, Shot4 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot5 -> Left, Shot5 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot6 -> Left, Shot6 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot7 -> Left, Shot7 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot8 -> Left, Shot8 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot9 -> Left, Shot9 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot10 -> Left, Shot10 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot11 -> Left, Shot11 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
		  Enemy2 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy2 -> Left, Enemy2 -> Top, Shot12 -> Left, Shot12 -> Top) == true)
	  {
		  Enemy2 -> Enabled = false;
		  Enemy2 -> Visible = false;
          Enemy2 -> Left = -100;
		  n++;
	  }



       if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot1 -> Left, Shot1 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot2 -> Left, Shot2 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot3 -> Left, Shot3 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot4 -> Left, Shot4 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot5 -> Left, Shot5 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot6 -> Left, Shot6 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot7 -> Left, Shot7 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot8 -> Left, Shot8 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot9 -> Left, Shot9 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot10 -> Left, Shot10 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot11 -> Left, Shot11 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }
	  if (check_collision(Enemy3 -> Left, Enemy3 -> Top, Shot12 -> Left, Shot12 -> Top) == true)
	  {
		  Enemy3 -> Enabled = false;
		  Enemy3 -> Visible = false;
		  Enemy3 -> Left = -100;
		  n++;
	  }


	  if(n==3)
	  {
          Button1 -> Caption = "You win! Restart?";
		  Button1 -> Enabled = true;
		  Button1 -> Visible = true;
	  }
	  if(p==0)
	  {
		  Button1 -> Caption = "You lose! Restart?";
          Button1 -> Enabled = true;
		  Button1 -> Visible = true;

      }



}
//---------------------------------------------------------------------------



void __fastcall TForm1::Button1Click(TObject *Sender)
{
   	direction1 = rand()%8;
	direction2 = rand()%8;
	direction3 = rand()%8;


	Enemy1 -> Left = rand()%577 + Back -> Left + 50;
	Enemy2 -> Left = rand()%577 + Back -> Left + 50;
	Enemy3 -> Left = rand()%577 + Back -> Left + 50;

	Enemy1 -> Top =  rand()%150;
	Enemy2 -> Top =  rand()%150;
	Enemy3 -> Top =  rand()%150;

 a = false; b = false; c = false; d = false; e = false; f = false;
 g = false; h = false; i = false; j = false; k = false; l = false;
 x1 =5; z1 =5; xy1 = 3;
 x2 =5; z2 =5; xy2 = 3;
 x3 =5; z3 =5; xy3 = 3;
 n = 0;
 p = 12;


 Enemy1 -> Enabled = true;
 Enemy2 -> Enabled = true;
 Enemy3 -> Enabled = true;
 Enemy1 -> Visible = true;
 Enemy2 -> Visible = true;
 Enemy3 -> Visible = true;


 Shot1 -> Left = 20;
 Shot2 -> Left = 512;
 Shot3 -> Left = 528;
 Shot4 -> Left = 544;
 Shot5 -> Left = 560;
 Shot6 -> Left = 576;
 Shot7 -> Left = 592;
 Shot8 -> Left = 608;
 Shot9 -> Left = 624;
 Shot10 -> Left = 640;
 Shot11 -> Left = 656;
 Shot12 -> Left = 672;

 Shot1 -> Left = 755;
 Shot2 -> Left = 755;
 Shot3 -> Left = 755;
 Shot4 -> Left = 755;
 Shot5 -> Left = 755;
 Shot6 -> Left = 755;
 Shot7 -> Left = 755;
 Shot8 -> Left = 755;
 Shot9 -> Left = 755;
 Shot10 -> Left = 755;
 Shot11 -> Left = 755;
 Shot12 -> Left = 755;

 Button1 ->  Enabled = false;
 Button1 -> Visible = false;




}
//---------------------------------------------------------------------------




void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
   Application -> Terminate();
}
//---------------------------------------------------------------------------

