//---------------------------------------------------------------------------

#ifndef Unit3H
#define Unit3H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Imaging.pngimage.hpp>
#include <Vcl.Imaging.jpeg.hpp>
#include <Vcl.Graphics.hpp>
#include <System.ImageList.hpp>
#include <Vcl.ImgList.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TImage *Image1;
	TTimer *TimerLeft;
	TTimer *TimerRight;
	TTimer *TimerUp;
	TTimer *TimerDown;
	TTimer *TimerShot;
	TImage *Back;
	TImage *Shot12;
	TImage *Shot11;
	TImage *Shot10;
	TImage *Shot9;
	TImage *Shot8;
	TImage *Shot7;
	TImage *Shot6;
	TImage *Shot5;
	TImage *Shot4;
	TImage *Shot3;
	TImage *Shot2;
	TImage *Shot1;
	TImage *Enemy1;
	TImage *Enemy2;
	TImage *Enemy3;
	TTimer *TimerEnemyMovement;
	TTimer *TimerCollision;
	TLabel *Label1;
	TButton *Button1;
	TLabel *Label2;
	TLabel *Label3;
	void __fastcall TimerLeftTimer(TObject *Sender);
	void __fastcall TimerRightTimer(TObject *Sender);
	void __fastcall FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall TimerUpTimer(TObject *Sender);
	void __fastcall TimerDownTimer(TObject *Sender);
	void __fastcall TimerShotTimer(TObject *Sender);
	void __fastcall TimerEnemyMovementTimer(TObject *Sender);
	void __fastcall TimerCollisionTimer(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);


};




//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------





#endif
